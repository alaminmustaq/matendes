export const metadata = {
  title: "Utility Page",
};
const layout = ({ children }) => {
  return <div>{children}</div>;
};

export default layout;
