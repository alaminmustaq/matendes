export const metadata = {
  title: "Error Page",
};
const layout = ({ children }) => {
  return <div>{children}</div>;
};

export default layout;
