export const metadata = {
  title: "Unovis Flow map",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
