export const metadata = {
  title: "Unovis leaflet map",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
