export const metadata = {
  title: "Vector map",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
