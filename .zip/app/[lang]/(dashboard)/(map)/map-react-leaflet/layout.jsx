export const metadata = {
  title: "React Leaflet map",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
