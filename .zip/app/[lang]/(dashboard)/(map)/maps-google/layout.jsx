export const metadata = {
  title: "Google map",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
