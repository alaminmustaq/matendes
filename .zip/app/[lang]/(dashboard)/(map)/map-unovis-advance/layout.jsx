export const metadata = {
  title: "Unovis Advance map",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
