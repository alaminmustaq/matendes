import ViewFiles from "@/components/files/view-files"
const DocumentsPage = ()=>{
  return(
    <ViewFiles/>
  )
}
export default DocumentsPage;