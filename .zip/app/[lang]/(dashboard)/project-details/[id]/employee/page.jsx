import Employee from './component/Employee';
const EmployeePage = ()=>{
  return(
    <Employee />
  )
}
export default EmployeePage;