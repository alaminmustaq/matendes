import IncomeExpense from './component/IncomeExpense';
const IncomeExpensePage = ()=>{
  return(
    <IncomeExpense />
  )
}
export default IncomeExpensePage;