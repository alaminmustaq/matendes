import ProjectInfo from './overview/project-info'; 
const Overview = () => {
  return ( 
    <ProjectInfo />   
  );
};

export default Overview;