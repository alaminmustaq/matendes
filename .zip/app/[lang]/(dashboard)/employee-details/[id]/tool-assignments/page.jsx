import ToolAssignments from './component/ToolAssignments';
const ToolAssignmentsPage = ()=>{
  return(
    <ToolAssignments />
  )
}
export default ToolAssignmentsPage;