import FinancialInformation from "./component/FinancialInformation";

const FinancialInformationPage = () => {
  return <FinancialInformation />;
};

export default FinancialInformationPage;