import ProjectActivity from './component/ProjectActivity';
const ProjectActivityPage = ()=>{
  return(
    <ProjectActivity />
  )
}
export default ProjectActivityPage;