import EmployeeInfo from './overview/employee-info'; 
const Overview = () => {
  return ( 
    <EmployeeInfo />   
  );
};

export default Overview;