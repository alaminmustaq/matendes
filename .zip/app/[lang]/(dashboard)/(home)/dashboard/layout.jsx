export const metadata = {
  title: "Dashboard",
};

const Layout = ({ children }) => {
  return <>{children}</>;
};

export default Layout;
